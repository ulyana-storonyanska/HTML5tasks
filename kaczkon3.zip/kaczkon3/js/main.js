function myFunction() {
  var element = document.getElementById("mover");
  element.classList.add("animate");
}